import React from 'react'

export function Home() {
  return (
    <div>
      <p>This is Home page</p>
    </div>
  )
}
