import React from 'react';

export function Notes() {
  return (
    <div>
      <p>This is about React notes</p>
    </div>
  )
}
