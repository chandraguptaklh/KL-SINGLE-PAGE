import React from 'react'

export default function College() {
  return (
    <div>
      <p>
        This page is about College's
      </p>
    </div>
  )
}
