import React from 'react'

export default function Admission() {
  return (
    <div>
      <h1 className='h11'>Admission</h1>
        <p className='pp'>Please contact us or visit admission branch for admission</p>
    </div>
  )
}
