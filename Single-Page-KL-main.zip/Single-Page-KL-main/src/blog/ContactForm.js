import React from 'react'
import './btn.css'
function About() {
  return (
    <>
    <body>
        <h1 className='h11'>Contact Us</h1>
        <p className='pp'>Address: Green Fields, Vaddeswaram, Andhra Pradesh 522302
Phone: 086453 50200</p>
    </body>
    </>
  )
}

export default About