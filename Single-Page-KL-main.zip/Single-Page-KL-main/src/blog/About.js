import React from 'react'
import './btn.css'
function About() {
  return (
    <>
    <body>
        <h1 className='h11'>About Us</h1>
        <p className='pp'>K L Deemed to be University, formerly Koneru Lakshmaiah College of Engineering and Koneru Lakshmaiah University, is a higher educational institution Deemed to be University, located in Vaddeswaram, Guntur, Andhra Pradesh, India.</p>
    </body>
    </>
  )
}

export default About